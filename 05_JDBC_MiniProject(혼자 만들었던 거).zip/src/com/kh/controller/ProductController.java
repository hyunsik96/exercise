package com.kh.controller;

import java.util.ArrayList;

import com.kh.model.service.ProductService;
import com.kh.model.vo.Product;
import com.kh.view.ProductView;


public class ProductController {
	
	
	public void selectAll() {
		
		ArrayList<Product> list = new ProductService().selectAll();
		
		if(list.isEmpty()) {
			new ProductView().displayNodata("전체 조회 결과가 없습니다.");
		}
		else {
			new ProductView().displayList(list);
		}
	}
	
	
	public void insertProduct(String productId, String productName, int price, String description, int stock) {
		
		Product p = new Product(productId, productName, price, description, stock);
		
		int result = new ProductService().insertProduct(p);
		
		if(result > 0) {
			new ProductView().displaySuccess("상품 추가 성공");
		}
		else {
			new ProductView().displayFail("상품 추가 실패");
		}
	}

	
	public void selectByProductName(String keyword) {
		
		ArrayList<Product> list = new ProductService().selectByProductName(keyword);
		
		if(list.isEmpty()) {
			new ProductView().displayNodata(keyword + " 에 대한 검색 결과가 없습니다.");
		}
		else {
			new ProductView().displayList(list);
		}
	}
	
	
	public void updateProduct(String productId, int price, String description, int stock) {
		
		Product p = new Product();
		p.setProductId(productId);
		p.setPrice(price);
		p.setDescription(description);
		p.setStock(stock);
		
		int result = new ProductService().updateProduct(p);
		
		if(result > 0) {
			new ProductView().displaySuccess("상품 정보 수정 성공");
		}
		else {
			new ProductView().displayFail("상품 정보 수정 실패");
		}
	}
	

	public void deleteProduct(String productId) {
		
		int result = new ProductService().deleteProduct(productId);
		
		if(result > 0) {
			new ProductView().displaySuccess("상품 삭제 성공");
		}
		else {
			new ProductView().displayFail("상품 삭제 실패");
		}
	}
	
	
	public void selectByDescription(String description) {
		
		ArrayList<Product> list = new ProductService().selectByDescription(description);
		
		if(list.isEmpty()) {
			new ProductView().displayNodata(description + " 에 대한 검색 결과가 없습니다.");
		}
		else {
			new ProductView().displayList(list);
		}
	}
	

	
}







