package com.kh.view;

import java.util.ArrayList;
import java.util.Scanner;

import com.kh.controller.ProductController;
import com.kh.model.vo.Product;

public class ProductView {

	private Scanner sc = new Scanner(System.in);
	
	private ProductController pc = new ProductController();
	
	public void mainMenu() {
		
		while(true) {
			
			System.out.println("***** 제품 관리 프로그램 *****");
			System.out.println("1. 상품 전체 조회 하기");
			System.out.println("2. 상품 추가 하기");
			System.out.println("3. 상품명 검색 하기");
			System.out.println("4. 상품 정보 수정 하기");
			System.out.println("5. 상품 삭제 하기");
			System.out.println("6. 상품 상세정보로 검색 하기");
			System.out.println("0. 프로그램 종료하기");
			System.out.println("---------------------------");
			System.out.print("이용할 메뉴 선택 : ");
			int menu = sc.nextInt();
			sc.nextLine();
			
			switch(menu) {
				case 1 : selectAll(); break;
				case 2 : insertProduct(); break;
				case 3 : selectByProductName(); break;
				case 4 : updateProduct(); break;
				case 5 : deleteProduct(); break;
				case 6 : selectByDescription(); break;
				case 0 : System.out.println("프로그램을 종료합니다."); return;
				default : System.out.println("번호를 잘못 입력했습니다. 다시 입력해주세요.");
			}
		}
	}
	
	public void selectAll() {
		
		System.out.println("----- 상품 전체 조회 -----");
		
		pc.selectAll();
	}

	public void insertProduct() {
		
		System.out.println("----- 상품 추가 -----");
		
		System.out.print("상품아이디 : ");
		String productId = sc.nextLine();

		System.out.print("상품명 : ");
		String productName = sc.nextLine();

		System.out.print("상품가격 : ");
		int price = sc.nextInt();
		sc.nextLine();
		
		System.out.print("상품상세정보 : ");
		String description = sc.nextLine();
		
		System.out.print("재고 : ");
		int stock = sc.nextInt();
		sc.nextLine();
		
		pc.insertProduct(productId, productName, price, description, stock);
		
	}
	
	public void selectByProductName() {
		
		System.out.println("----- 상품명 키워드 검색 -----");
		
		System.out.print("상품명 키워드 입력 : ");
		String keyword = sc.nextLine();
		
		pc.selectByProductName(keyword);
		
	}
	
	public void updateProduct() {
		
		System.out.println("----- 상품정보 수정 -----");
		
		System.out.print("수정할 상품의 아이디 입력 : ");
		String productId = sc.nextLine();
		
		System.out.print("수정할 상품가격 : ");
		int price = sc.nextInt();
		sc.nextLine();
		
		System.out.print("수정할 상품상세정보 : ");
		String description = sc.nextLine();
		
		System.out.print("수정할 재고 : ");
		int stock = sc.nextInt();
		sc.nextLine();
		
		pc.updateProduct(productId, price, description, stock);
		
	}
	
	public void deleteProduct() {
		
		System.out.println("----- 상품 삭제 -----");
		
		System.out.print("삭제할 상품 아이디 : ");
		String productId = sc.nextLine();
		
		pc.deleteProduct(productId);
	}
	
	
	public void selectByDescription() {
		
		System.out.println("----- 상품 상세정보 검색 -----");
		
		System.out.print("상품 상세정보 입력 : ");
		String description = sc.nextLine();
		
		pc.selectByDescription(description);
		
	}
	
	
	public void displaySuccess(String message) {
		
		System.out.println("서비스 요청 성공 : " + message);
	}
	
	public void displayFail(String message) {
		
		System.out.println("서비스 요청 실패 : " + message);
	}
	
	public void displayNodata(String message) {
		
		System.out.println(message);
	}
	
	public void displayList(ArrayList<Product> list) {
		
		System.out.println("조회된 데이터는 총 " + list.size() + "건 입니다.");
		for(int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}
	}
	
	public void displayOne(Product p) {
		
		System.out.println("조회된 데이터는 다음과 같습니다.");
		
		System.out.println(p);
	}
	
}












